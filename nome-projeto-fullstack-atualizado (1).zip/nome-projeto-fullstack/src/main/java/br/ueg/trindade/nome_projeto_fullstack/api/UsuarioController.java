package br.ueg.trindade.nome_projeto_fullstack.api;

import java.util.List;
import java.util.Locale;
import br.ueg.trindade.nome_projeto_fullstack.model.Usuario;
import br.ueg.trindade.nome_projeto_fullstack.repository.UsuarioRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController @RequestMapping("/api/usuarios")
public class UsuarioController {
    private final UsuarioRepository usuarios;
    private final PasswordEncoder encoder;
    public UsuarioController(UsuarioRepository usuarios, PasswordEncoder encoder) { this.usuarios = usuarios; this.encoder = encoder; }
    @GetMapping public List<Dto.UsuarioResposta> listar() { return usuarios.findAll().stream().map(Dto.UsuarioResposta::de).toList(); }
    @GetMapping("/{id}") public Dto.UsuarioResposta obter(@PathVariable Long id) { return Dto.UsuarioResposta.de(buscar(id)); }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public Dto.UsuarioResposta criar(@Valid @RequestBody Dto.NovoUsuario d) {
        String email = d.email().trim().toLowerCase(Locale.ROOT);
        if (usuarios.existsByEmail(email)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Email já cadastrado");
        String username = d.username().trim().toLowerCase(Locale.ROOT);
        if (usuarios.existsByUsername(username)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Username já cadastrado");
        return Dto.UsuarioResposta.de(usuarios.save(new Usuario(d.nome().trim(), username, email, encoder.encode(d.senha()), Usuario.Papel.USER)));
    }
    @PutMapping("/{id}")
    public Dto.UsuarioResposta editar(@PathVariable Long id, @Valid @RequestBody Dto.EdicaoUsuario d) {
        Usuario u = buscar(id);
        String email = d.email().trim().toLowerCase(Locale.ROOT);
        if (!email.equals(u.email) && usuarios.existsByEmail(email)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Email já cadastrado");
        String username = d.username().trim().toLowerCase(Locale.ROOT);
        if (!username.equals(u.username) && usuarios.existsByUsername(username)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Username já cadastrado");
        u.nome = d.nome().trim(); u.username = username; u.email = email; u.papel = d.papel();
        if (d.senha() != null && !d.senha().isBlank()) {
            if (d.senha().length() < 8) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Senha deve ter pelo menos 8 caracteres");
            u.senha = encoder.encode(d.senha());
        }
        return Dto.UsuarioResposta.de(usuarios.save(u));
    }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void excluir(@PathVariable Long id) { usuarios.delete(buscar(id)); }
    private Usuario buscar(Long id) { return usuarios.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuário não encontrado")); }
}
