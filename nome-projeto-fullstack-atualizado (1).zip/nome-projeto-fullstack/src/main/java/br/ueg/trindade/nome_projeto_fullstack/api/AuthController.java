package br.ueg.trindade.nome_projeto_fullstack.api;

import br.ueg.trindade.nome_projeto_fullstack.model.Usuario;
import br.ueg.trindade.nome_projeto_fullstack.repository.UsuarioRepository;
import br.ueg.trindade.nome_projeto_fullstack.security.JwtService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.Locale;

@RestController @RequestMapping("/api/auth")
public class AuthController {
    private final UsuarioRepository usuarios;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    public AuthController(UsuarioRepository usuarios, PasswordEncoder encoder, JwtService jwt) {
        this.usuarios = usuarios; this.encoder = encoder; this.jwt = jwt;
    }
    @PostMapping("/registro") @ResponseStatus(HttpStatus.CREATED)
    public Dto.TokenResposta registrar(@Valid @RequestBody Dto.NovoUsuario dados) {
        String email = dados.email().trim().toLowerCase(Locale.ROOT);
        if (usuarios.existsByEmail(email)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Email já cadastrado");
        String username = dados.username().trim().toLowerCase(Locale.ROOT);
        if (usuarios.existsByUsername(username)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Username já cadastrado");
        Usuario usuario = usuarios.save(new Usuario(dados.nome().trim(), username, email, encoder.encode(dados.senha()), Usuario.Papel.USER));
        return new Dto.TokenResposta(jwt.criar(usuario.email), Dto.UsuarioResposta.de(usuario));
    }
    @PostMapping("/login")
    public Dto.TokenResposta login(@Valid @RequestBody Dto.Credenciais dados) {
        Usuario usuario = usuarios.findByEmail(dados.email().trim().toLowerCase(Locale.ROOT))
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciais inválidas"));
        if (!encoder.matches(dados.senha(), usuario.senha)) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciais inválidas");
        return new Dto.TokenResposta(jwt.criar(usuario.email), Dto.UsuarioResposta.de(usuario));
    }
}
