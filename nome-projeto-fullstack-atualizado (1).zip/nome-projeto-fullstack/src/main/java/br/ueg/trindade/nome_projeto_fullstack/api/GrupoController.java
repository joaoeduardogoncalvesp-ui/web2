package br.ueg.trindade.nome_projeto_fullstack.api;

import java.util.List;
import br.ueg.trindade.nome_projeto_fullstack.model.Grupo;
import br.ueg.trindade.nome_projeto_fullstack.repository.GrupoRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController @RequestMapping("/api/grupos")
public class GrupoController {
    private final GrupoRepository grupos;
    public GrupoController(GrupoRepository grupos) { this.grupos = grupos; }
    @GetMapping public List<Grupo> listar() { return grupos.findAll(); }
    @GetMapping("/{id}") public Grupo obter(@PathVariable Long id) { return buscar(id); }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public Grupo criar(@Valid @RequestBody Dto.GrupoDados d) { return grupos.save(new Grupo(d.nome().trim(), d.descricao())); }
    @PutMapping("/{id}") public Grupo editar(@PathVariable Long id, @Valid @RequestBody Dto.GrupoDados d) {
        Grupo g = buscar(id); g.nome = d.nome().trim(); g.descricao = d.descricao(); return grupos.save(g);
    }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void excluir(@PathVariable Long id) { grupos.delete(buscar(id)); }
    private Grupo buscar(Long id) { return grupos.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Grupo não encontrado")); }
}
