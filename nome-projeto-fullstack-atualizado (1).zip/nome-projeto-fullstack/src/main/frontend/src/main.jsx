import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import './style.css'
import UsuarioList from './components/UsuarioList'
import PermissoesPage from './pages/PermissoesPage'
import CategoriaList from './components/CategoriaList'

const api = async (path, method = 'GET', body, token) => {
  const response = await fetch(`/api${path}`, {
    method,
    headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  })
  if (!response.ok) {
    let error = `Erro ${response.status}`
    try { const data = await response.json(); error = data.detail || data.message || error } catch { /* resposta vazia */ }
    throw new Error(error)
  }
  return response.status === 204 ? null : response.json()
}

function App() {
  const [session, setSession] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem('session')) } catch { return null }
  })
  const [mode, setMode] = useState('login')
  const [tab, setTab] = useState('grupos')
  const [groups, setGroups] = useState([])
  const [authForm, setAuthForm] = useState({ nome: '', username: '', email: '', senha: '' })
  const [form, setForm] = useState({ nome: '', descricao: '' })
  const [editing, setEditing] = useState(null)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const admin = session?.usuario.papel === 'ADMIN'
  const token = session?.token

  const refresh = async () => {
    if (!token) return
    try {
      setGroups(await api('/grupos', 'GET', null, token))
      setError('')
    } catch (e) { setError(e.message) }
  }
  useEffect(() => { refresh() }, [token, admin])

  const authenticate = async (e) => {
    e.preventDefault(); setError(''); setNotice('')
    try {
      const data = await api(mode === 'login' ? '/auth/login' : '/auth/registro', 'POST', authForm)
      sessionStorage.setItem('session', JSON.stringify(data))
      setSession(data)
      setAuthForm({ nome: '', username: '', email: '', senha: '' })
    } catch (e) { setError(e.message) }
  }
  const logout = () => { sessionStorage.removeItem('session'); setSession(null); setGroups([]); setError('') }
  const reset = () => { setEditing(null); setForm({ nome: '', descricao: '' }) }
  const save = async (e) => {
    e.preventDefault(); setError(''); setNotice('')
    try {
      await api(editing ? `/grupos/${editing}` : '/grupos', editing ? 'PUT' : 'POST', form, token)
      reset(); setNotice('Salvo com sucesso.'); await refresh()
    } catch (e) { setError(e.message) }
  }
  const remove = async (item) => {
    if (!window.confirm(`Excluir ${item.nome}?`)) return
    try {
      await api(`/${tab}/${item.id}`, 'DELETE', null, token)
      setNotice('Excluído com sucesso.'); setError(''); reset(); await refresh()
    } catch (e) { setError(e.message) }
  }
  const edit = (item) => {
    setEditing(item.id)
    setForm({ nome: item.nome, descricao: item.descricao || '' })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return <main>
    <header><div><h1>Projeto Fullstack</h1><p>Usuários, grupos, permissões e categorias</p></div>{session && <button onClick={logout}>Sair</button>}</header>
    {error && <p className="alert" role="alert">{error}</p>}
    {notice && <p className="notice" role="status">{notice}</p>}
    {!session ? <section className="card">
      <nav><button className={mode === 'login' ? 'active' : ''} onClick={() => { setMode('login'); setError('') }}>Entrar</button><button className={mode === 'registro' ? 'active' : ''} onClick={() => { setMode('registro'); setError('') }}>Cadastrar</button></nav>
      <form onSubmit={authenticate}>
        {mode === 'registro' && <><label>Nome<input required value={authForm.nome} onChange={e => setAuthForm({ ...authForm, nome: e.target.value })} /></label><label>Username<input required value={authForm.username} onChange={e => setAuthForm({ ...authForm, username: e.target.value })} /></label></>}
        <label>Email<input required type="email" value={authForm.email} onChange={e => setAuthForm({ ...authForm, email: e.target.value })} /></label>
        <label>Senha<input required type="password" minLength={mode === 'registro' ? 8 : undefined} value={authForm.senha} onChange={e => setAuthForm({ ...authForm, senha: e.target.value })} /></label>
        <button type="submit">{mode === 'login' ? 'Entrar' : 'Criar conta'}</button>
      </form>
    </section> : <>
      <p>Olá, {session.usuario.nome} ({session.usuario.papel})</p>
      <nav><button className={tab === 'grupos' ? 'active' : ''} onClick={() => { setTab('grupos'); reset() }}>Grupos</button>{admin && <button className={tab === 'usuarios' ? 'active' : ''} onClick={() => { setTab('usuarios'); reset() }}>Usuários</button>}<button className={tab === 'permissoes' ? 'active' : ''} onClick={() => { setTab('permissoes'); reset() }}>Permissões</button><button className={tab === 'categorias' ? 'active' : ''} onClick={() => { setTab('categorias'); reset() }}>Categorias</button></nav>
      {admin && tab === 'grupos' && <section className="card"><h2>{editing ? 'Editar' : 'Novo'} grupo</h2>
        <form onSubmit={save}>
          <label>Nome<input required value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} /></label>
          <label>Descrição<textarea value={form.descricao} onChange={e => setForm({ ...form, descricao: e.target.value })} /></label>
          <div className="actions"><button type="submit">Salvar</button>{editing && <button type="button" onClick={reset}>Cancelar</button>}</div>
        </form>
      </section>}
      {tab === 'usuarios' && admin && <UsuarioList />}
      {tab === 'permissoes' && <PermissoesPage admin={admin} />}
      {tab === 'categorias' && <CategoriaList admin={admin} />}
      {tab === 'grupos' && <section className="card"><h2>Lista de grupos</h2>
        {groups.map(item => <article key={item.id}>
          <div><strong>{item.nome}</strong><p>{item.descricao}</p></div>
          {admin && <div className="actions"><button onClick={() => edit(item)}>Editar</button><button onClick={() => remove(item)}>Excluir</button></div>}
        </article>)}
        {groups.length === 0 && <p>Nenhum grupo cadastrado.</p>}
      </section>}
    </>}
  </main>
}

createRoot(document.getElementById('root')).render(<App />)
