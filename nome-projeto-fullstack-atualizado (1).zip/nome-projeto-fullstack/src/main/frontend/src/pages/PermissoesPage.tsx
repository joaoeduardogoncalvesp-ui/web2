import PermissaoList from '../components/PermissaoList'

export default function PermissoesPage({ admin }: { admin: boolean }) {
  return <section aria-label="Página de permissões">
    <h2>Gerenciamento de permissões</h2>
    <PermissaoList admin={admin} />
  </section>
}
